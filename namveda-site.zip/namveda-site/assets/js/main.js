/* ============================================================
   NAMVEDA AYURVEDA — Main JS
   ============================================================ */
'use strict';

/* ── Data ── */
const PRODUCTS = [
  {
    id:1, name:"Chandan Soothe", category:"Skincare", price:250, mrp:299,
    badge:"Best Seller",
    images:["https://i.imgur.com/jwGh3eu.png","https://i.imgur.com/D3kJXpO.jpeg","https://i.imgur.com/clySwyH.jpeg"],
    desc:"Chandan Soothe is a gentle face care product enriched with natural sandalwood. It helps calm the skin, reduces irritation, and leaves your face feeling soft and refreshed. Perfect for daily use, giving your skin a healthy glow and helping it stay smooth and comfortable throughout the day. Its natural ingredients work to protect the skin from dryness and stress caused by the environment.",
    benefits:["Calms and refreshes the skin","Reduces irritation and redness","Softens and smoothens the skin","Gives a natural healthy glow","Suitable for all skin types","Gentle enough for daily use"]
  },
  {
    id:2, name:"Mulethi Glow", category:"Skincare", price:250, mrp:299,
    badge:"",
    images:["https://i.imgur.com/7IU1ewO.jpeg","https://i.imgur.com/U3VY2rR.jpeg","https://i.imgur.com/b3RJxSs.jpeg"],
    desc:"Mulethi Glow is a face care product made with natural mulethi (licorice) extracts. It helps brighten the skin, reduce dark spots, and improve overall complexion. Regular use makes your skin look fresh, radiant, and healthy. Gentle and suitable for all skin types.",
    benefits:["Brightens and evens skin tone","Reduces dark spots and pigmentation","Improves overall complexion","Gives a radiant, fresh appearance","Suitable for all skin types","Free from harsh chemicals"]
  },
  {
    id:3, name:"Manjistha Detox", category:"Wellness & Detox", price:250, mrp:299,
    badge:"New",
    images:["https://i.imgur.com/bANqiIq.jpeg","https://i.imgur.com/jwGh3eu.png","https://i.imgur.com/D3kJXpO.jpeg"],
    desc:"Manjistha Detox is a powerful Ayurvedic wellness product formulated with Manjistha root extract. It supports the body's natural detoxification processes, purifies the blood, and promotes clear, healthy skin. Rich in antioxidants, it also supports liver function and overall vitality.",
    benefits:["Supports natural detoxification","Purifies the blood naturally","Promotes clear, healthy skin","Rich in powerful antioxidants","Supports liver and kidney function","Boosts overall energy and vitality"]
  },
  {
    id:4, name:"Bhringraj Scalp Oil", category:"Haircare", price:280, mrp:349,
    badge:"",
    images:["https://i.imgur.com/D3kJXpO.jpeg","https://i.imgur.com/clySwyH.jpeg","https://i.imgur.com/7IU1ewO.jpeg"],
    desc:"Bhringraj Scalp Oil is a premium Ayurvedic hair oil formulated with the king of herbs — Bhringraj. It deeply nourishes the scalp, strengthens hair roots, reduces hair fall, and promotes healthy hair growth. Regular use results in thicker, lustrous, and stronger hair.",
    benefits:["Deeply nourishes the scalp","Strengthens hair roots","Reduces hair fall significantly","Promotes healthy hair growth","Adds lustre and shine","Conditions and softens hair"]
  },
  {
    id:5, name:"Neem Purify Face Wash", category:"Skincare", price:199, mrp:249,
    badge:"",
    images:["https://i.imgur.com/clySwyH.jpeg","https://i.imgur.com/jwGh3eu.png","https://i.imgur.com/U3VY2rR.jpeg"],
    desc:"Neem Purify Face Wash is a gentle, antibacterial cleanser powered by the age-old healing properties of neem. It removes excess oil, dirt, and impurities without stripping the skin of its natural moisture. Ideal for acne-prone and oily skin types.",
    benefits:["Deep cleanses pores","Controls excess sebum production","Fights acne-causing bacteria","Leaves skin feeling fresh","Gentle on sensitive skin","Prevents breakouts naturally"]
  },
  {
    id:6, name:"Amla Hair Mask", category:"Haircare", price:220, mrp:279,
    badge:"",
    images:["https://i.imgur.com/U3VY2rR.jpeg","https://i.imgur.com/b3RJxSs.jpeg","https://i.imgur.com/bANqiIq.jpeg"],
    desc:"Amla Hair Mask is an intensive conditioning treatment enriched with Indian gooseberry (amla) extracts. It deeply moisturises dry, brittle hair, adds natural shine, and improves overall hair health. Rich in vitamin C and antioxidants for stronger, healthier hair.",
    benefits:["Deeply moisturises dry hair","Adds natural shine and softness","Strengthens hair from root to tip","Rich in Vitamin C","Reduces frizz and breakage","Improves overall hair health"]
  },
  {
    id:7, name:"Triphala Digest", category:"Wellness & Detox", price:299, mrp:369,
    badge:"",
    images:["https://i.imgur.com/b3RJxSs.jpeg","https://i.imgur.com/bANqiIq.jpeg","https://i.imgur.com/D3kJXpO.jpeg"],
    desc:"Triphala Digest is an Ayurvedic digestive supplement combining three powerful fruits — Amalaki, Bibhitaki, and Haritaki. This ancient formulation supports healthy digestion, regular bowel movements, and gentle detoxification of the digestive tract.",
    benefits:["Supports healthy digestion","Promotes regular bowel movements","Gentle digestive detox","Balances all three doshas","Boosts nutrient absorption","Supports gut microbiome health"]
  },
  {
    id:8, name:"Rose Water Toner", category:"Skincare", price:179, mrp:220,
    badge:"",
    images:["https://i.imgur.com/7IU1ewO.jpeg","https://i.imgur.com/jwGh3eu.png","https://i.imgur.com/clySwyH.jpeg"],
    desc:"Rose Water Toner is a pure, natural face toner made with real rose water. It hydrates, refreshes, and balances the skin's pH level. Suitable for all skin types, it minimises pores, reduces redness, and prepares the skin for optimal absorption of serums and moisturisers.",
    benefits:["Hydrates and refreshes skin instantly","Balances skin pH naturally","Minimises the appearance of pores","Reduces redness and irritation","Prepares skin for serums","Suitable for all skin types"]
  }
];

const CATEGORIES = [
  { name:"Skincare",         img:"https://i.imgur.com/jwGh3eu.png" },
  { name:"Haircare",         img:"https://i.imgur.com/D3kJXpO.jpeg" },
  { name:"Wellness & Detox", img:"https://i.imgur.com/bANqiIq.jpeg" },
  { name:"Skincare",         img:"https://i.imgur.com/clySwyH.jpeg" },
  { name:"Haircare",         img:"https://i.imgur.com/U3VY2rR.jpeg" },
  { name:"Wellness & Detox", img:"https://i.imgur.com/b3RJxSs.jpeg" },
];

const TESTIMONIALS = [
  { name:"Priya Sharma",    age:"28", loc:"Mumbai", rating:5, text:"Chandan Soothe transformed my skin in just 2 weeks! My skin feels calmer and looks brighter. Absolutely in love with these natural products." },
  { name:"Arjun Mehta",     age:"35", loc:"Delhi", rating:5, text:"The Manjistha Detox has helped my digestion tremendously. I feel lighter and my skin has cleared up. Truly amazing Ayurvedic products." },
  { name:"Kavitha Nair",    age:"42", loc:"Bangalore", rating:5, text:"Bhringraj Oil is incredible! My hair fall has reduced drastically and my hair looks shinier than ever. Worth every rupee." },
  { name:"Rohit Gupta",     age:"31", loc:"Pune", rating:5, text:"I've tried many products but Namveda stands apart. Pure, natural, and genuinely effective. The packaging is also beautiful." },
  { name:"Sneha Patel",     age:"26", loc:"Ahmedabad", rating:5, text:"Mulethi Glow has evened out my skin tone and the dark spots have visibly faded. Customer service is also wonderful." },
  { name:"Vikram Singh",    age:"38", loc:"Jaipur", rating:5, text:"Fast delivery, premium packaging, and products that actually work. Namveda Ayurveda is my go-to for wellness products." },
];

const FAQS = [
  { q:"Are Namveda Ayurveda products 100% natural?", a:"Yes, all our products are formulated with carefully sourced natural and Ayurvedic ingredients. We do not use harmful chemicals, artificial fragrances, or synthetic additives. Every formula is inspired by ancient Ayurvedic wisdom." },
  { q:"How long does delivery take?", a:"We typically dispatch orders within 1-2 business days. Delivery across India usually takes 5-7 business days depending on your location. You will receive tracking updates via WhatsApp." },
  { q:"What is your return policy?", a:"We accept returns of unopened products within 7 days of delivery. If you receive a defective or damaged product, please contact us immediately via WhatsApp with photos and we will arrange a replacement or full refund." },
  { q:"Are the products dermatologically tested?", a:"Our products are formulated by expert Ayurvedic practitioners and are made with ingredients that have been trusted for centuries. We recommend doing a small patch test before first use if you have sensitive skin." },
  { q:"Can I use multiple Namveda products together?", a:"Absolutely! Our products are designed to complement each other. For example, the Neem Purify Face Wash pairs beautifully with the Mulethi Glow and Rose Water Toner for a complete skincare routine." },
  { q:"Do you offer bulk or wholesale orders?", a:"Yes, we cater to bulk and wholesale orders for salons, wellness centres, and retailers. Please contact us directly via WhatsApp at +91 8109665754 for bulk pricing and enquiries." },
];

const POLICIES = {
  'Return Policy': `Our Return Policy\n\nAt Namveda Ayurveda, we want you to be completely satisfied with your purchase. If for any reason you are not happy, you may return unopened products within 7 days of delivery.\n\nTo initiate a return, please contact us via WhatsApp at +91 8109665754 with your order details. Refunds are processed within 5-7 business days after we receive the returned product.\n\nPlease note that opened or used products cannot be returned due to hygiene reasons, unless they are defective.`,
  'Privacy Policy': `Privacy Policy\n\nYour privacy is important to us. Namveda Ayurveda collects personal information (name, email, phone, address) solely to process your orders and provide customer support.\n\nWe do not sell, trade, or share your information with third parties. Our website may use cookies to improve user experience. By using our website, you consent to our privacy practices.\n\nFor any concerns, contact us at +91 8109665754.`,
  'Store Policies': `Store Policies\n\nNameveda Ayurveda strives to deliver premium natural products safely and promptly. All orders are processed within 1-2 business days. We offer free delivery on all orders across India.\n\nPrices are inclusive of all taxes. Products are shipped in secure packaging to maintain quality. For bulk orders or special enquiries, contact us via WhatsApp at +91 8109665754.`,
  'Track your Orders': `Track Your Orders\n\nTo track your order, please reach out to us via WhatsApp at +91 8109665754 with your Order ID. We will provide you with real-time updates on your delivery status.\n\nTypically, orders are delivered within 5-7 business days after dispatch.`,
};

/* ── State ── */
let cart = JSON.parse(localStorage.getItem('nv_cart') || '[]');
let wishlist = JSON.parse(localStorage.getItem('nv_wish') || '[]');
let currentUser = JSON.parse(localStorage.getItem('nv_user') || 'null');
let prevPage = 'home';
let currentFilter = 'all';
let checkoutStep = 1;
let checkoutData = {};
let checkoutPM = 'upi';

/* ── Persistence ── */
const saveCart = () => localStorage.setItem('nv_cart', JSON.stringify(cart));
const saveWish = () => localStorage.setItem('nv_wish', JSON.stringify(wishlist));

/* ── Toast ── */
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}

/* ── Cart Badge ── */
function updateCartBadge() {
  const count = cart.reduce((s, c) => s + c.qty, 0);
  const el = document.getElementById('cart-count');
  if (el) el.textContent = count;
}

/* ── Page Navigation ── */
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById('page-' + id);
  if (page) {
    page.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  if (id === 'cart') renderCart();
  if (id === 'wishlist') renderWishlist();
  if (id === 'checkout') renderCheckout(1);
  if (id !== 'home') prevPage = 'home';
  updateCartBadge();

  // Trigger reveal animations on newly active page
  setTimeout(() => {
    revealObserver && page && page.querySelectorAll('.rv:not(.visible)').forEach(el => revealObserver.observe(el));
  }, 80);
}

function goBack() { showPage(prevPage || 'home'); }

/* ── Category Carousel ── */
function buildCatCarousel() {
  const track = document.getElementById('cat-track');
  if (!track) return;
  const items = [...CATEGORIES, ...CATEGORIES]; // duplicate for loop
  track.innerHTML = items.map(c => `
    <div class="cat-item" onclick="filterCategory('${c.name}')">
      <div class="cat-circle"><img src="${c.img}" alt="${c.name}" loading="lazy"></div>
      <span>${c.name}</span>
    </div>`).join('');
  addDragSwipe(track, 'catScroll', 22000);
}

/* ── Testimonials ── */
function buildTestimonials() {
  const track = document.getElementById('test-track');
  if (!track) return;
  const items = [...TESTIMONIALS, ...TESTIMONIALS];
  track.innerHTML = items.map(t => `
    <div class="test-card">
      <div class="test-stars">${'★'.repeat(t.rating)}</div>
      <div class="test-text">"${t.text}"</div>
      <div class="test-author"><strong>${t.name}</strong><span>${t.age} · ${t.loc}</span></div>
    </div>`).join('');
  addDragSwipe(track, 'testScroll', 36000);
}

/* ── Drag Swipe for Carousels ── */
function addDragSwipe(el, animName, dur) {
  let isDragging = false, startX = 0, startOff = 0, velX = 0, lastX = 0, lastT = 0;

  function getOff() {
    return new DOMMatrix(window.getComputedStyle(el).transform).m41;
  }

  function start(x) {
    isDragging = true; startX = x; lastX = x; lastT = Date.now(); velX = 0;
    startOff = getOff();
    el.style.animation = 'none';
    el.style.transition = 'none';
    el.style.transform = `translateX(${startOff}px)`;
  }

  function move(x) {
    if (!isDragging) return;
    const now = Date.now(), dt = now - lastT || 1;
    velX = (x - lastX) / dt * 16;
    lastX = x; lastT = now;
    el.style.transform = `translateX(${startOff + (x - startX)}px)`;
  }

  function end() {
    if (!isDragging) return;
    isDragging = false;
    const off = startOff + (lastX - startX) + velX * 8;
    const half = el.scrollWidth / 2;
    const clamped = ((-off % half) + half) % half;
    el.style.transition = 'transform .36s cubic-bezier(.25,.46,.45,.94)';
    el.style.transform = `translateX(${-clamped}px)`;
    setTimeout(() => {
      const progress = clamped / half;
      el.style.transition = '';
      el.style.animation = `${animName} ${dur/1000}s linear infinite`;
      el.style.animationDelay = `-${progress * dur/1000}s`;
      el.style.transform = '';
    }, 380);
  }

  el.addEventListener('touchstart', e => { if (e.touches.length === 1) start(e.touches[0].clientX); }, { passive: true });
  el.addEventListener('touchmove', e => { if (isDragging) { e.preventDefault(); move(e.touches[0].clientX); } }, { passive: false });
  el.addEventListener('touchend', end, { passive: true });
  el.addEventListener('mousedown', e => { start(e.clientX); e.preventDefault(); });
  window.addEventListener('mousemove', e => { if (isDragging) move(e.clientX); });
  window.addEventListener('mouseup', () => { if (isDragging) end(); });
}

/* ── FAQ ── */
function buildFAQ() {
  const el = document.getElementById('faq-list');
  if (!el) return;
  el.innerHTML = FAQS.map((f, i) => `
    <div class="faq-item rv rv-up rv-d${Math.min(i+1,6)}" id="faq-${i}">
      <div class="faq-q" onclick="toggleFaq(${i})" role="button" tabindex="0" onkeydown="if(event.key==='Enter')toggleFaq(${i})">
        <span class="faq-q-text">${f.q}</span>
        <span class="faq-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
        </span>
      </div>
      <div class="faq-a">${f.a}</div>
    </div>`).join('');
}

function toggleFaq(i) {
  const item = document.getElementById('faq-' + i);
  item.classList.toggle('open');
}

/* ── Product Card ── */
function productCard(p) {
  const inWish = wishlist.includes(p.id);
  return `
    <div class="product-card rv rv-up">
      <div class="product-img" onclick="showProduct(${p.id})" style="cursor:pointer">
        <img src="${p.images[0]}" alt="${p.name}" loading="lazy">
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ''}
        <button class="product-wish ${inWish?'active':''}" onclick="event.stopPropagation();toggleWish(${p.id},this)" title="Wishlist">
          <svg viewBox="0 0 24 24" fill="${inWish?'#e05555':'none'}" stroke="${inWish?'#e05555':'currentColor'}" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </button>
      </div>
      <div class="product-info">
        <div class="product-cat">${p.category}</div>
        <div class="product-name" onclick="showProduct(${p.id})" style="cursor:pointer">${p.name}</div>
        <div class="product-price">₹${p.price} <span class="mrp">₹${p.mrp}</span></div>
        <div class="product-btns">
          <button class="btn-cart" onclick="addToCart(${p.id})">Add to Cart</button>
          <button class="btn-buy"  onclick="buyNow(${p.id})">Buy Now</button>
        </div>
      </div>
    </div>`;
}

function renderHomeProducts() {
  const g = document.getElementById('home-products-grid');
  if (g) g.innerHTML = PRODUCTS.slice(0,4).map(p => productCard(p)).join('');
}

function renderShopGrid(filter = 'all') {
  currentFilter = filter;
  const filtered = filter === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.category === filter);
  const title = document.getElementById('shop-title');
  if (title) title.innerHTML = filter === 'all' ? 'All <em>Products</em>' : `${filter} <em>Products</em>`;
  const bc = document.getElementById('shop-breadcrumb');
  if (bc) bc.textContent = filter === 'all' ? 'All Products' : filter;
  const grid = document.getElementById('shop-grid');
  if (grid) grid.innerHTML = filtered.map(p => productCard(p)).join('');
  setTimeout(() => initReveal(), 60);
}

function filterCategory(cat) {
  currentFilter = cat;
  renderShopGrid(cat);
  showPage('shop');
}

/* ── Product Detail ── */
function showProduct(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  prevPage = document.querySelector('.page.active')?.id.replace('page-', '') || 'home';
  const bcName = document.getElementById('pd-breadcrumb-name');
  if (bcName) bcName.textContent = p.name;
  const content = document.getElementById('pd-content');
  if (content) content.innerHTML = `
    <div class="pd-img-section rv rv-left">
      <div class="pd-main-img"><img id="pd-main-img" src="${p.images[0]}" alt="${p.name}"></div>
      <div class="pd-thumbs">
        ${p.images.map((img,i) => `<div class="pd-thumb ${i===0?'active':''}" onclick="selectThumb(this,'${img}')"><img src="${img}" alt="" loading="lazy"></div>`).join('')}
      </div>
    </div>
    <div class="pd-info rv rv-right">
      <div style="font-size:.72rem;letter-spacing:1.5px;text-transform:uppercase;color:var(--accent);margin-bottom:8px">${p.category}</div>
      <div class="product-name">${p.name}</div>
      <div class="product-price" style="font-size:1.4rem;margin:12px 0">₹${p.price} <span class="mrp">₹${p.mrp}</span></div>
      <div class="pd-desc collapsed" id="pd-desc">${p.desc}</div>
      <button class="see-more" id="see-more-btn" onclick="toggleSeeMore()">See More ▾</button>
      <div class="pd-benefits">
        <h3>Key Benefits</h3>
        <ul>${p.benefits.map(b => `<li>${b}</li>`).join('')}</ul>
      </div>
      <div class="pd-btns">
        <button class="pd-btn-cart" onclick="addToCart(${p.id});showToast('Added to cart!')">Add to Cart</button>
        <button class="pd-btn-buy" onclick="buyNow(${p.id})">Buy Now</button>
      </div>
      <div style="margin-top:16px;display:flex;align-items:center;gap:8px">
        <button class="product-wish ${wishlist.includes(p.id)?'active':''}" id="pd-wish-btn" onclick="toggleWish(${p.id},this)" style="position:relative;top:0;right:0;background:var(--light-green)">
          <svg viewBox="0 0 24 24" fill="${wishlist.includes(p.id)?'#e05555':'none'}" stroke="${wishlist.includes(p.id)?'#e05555':'currentColor'}" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </button>
        <span style="font-size:.82rem;color:var(--text-muted)">${wishlist.includes(p.id)?'Saved to Wishlist':'Save to Wishlist'}</span>
      </div>
    </div>`;
  showPage('product');
}

function selectThumb(el, src) {
  document.querySelectorAll('.pd-thumb').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  const img = document.getElementById('pd-main-img');
  if (img) { img.style.opacity = '0'; setTimeout(() => { img.src = src; img.style.opacity = '1'; }, 180); }
}

function toggleSeeMore() {
  const desc = document.getElementById('pd-desc');
  const btn = document.getElementById('see-more-btn');
  if (desc.classList.toggle('collapsed')) { btn.textContent = 'See More ▾'; }
  else { btn.textContent = 'See Less ▴'; }
}

/* ── Cart ── */
function addToCart(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const ex = cart.find(c => c.id === id);
  if (ex) { ex.qty++; } else { cart.push({ id, qty: 1 }); }
  saveCart();
  updateCartBadge();
  showToast(`${p.name} added to cart!`);
}

function removeFromCart(id) {
  cart = cart.filter(c => c.id !== id);
  saveCart(); updateCartBadge(); renderCart();
}

function updateQty(id, delta) {
  const item = cart.find(c => c.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty < 1) return removeFromCart(id);
  saveCart(); renderCart();
}

function clearCart() { cart = []; saveCart(); updateCartBadge(); }
function getCartTotal() { return cart.reduce((s, c) => { const p = PRODUCTS.find(x => x.id===c.id); return s + (p ? p.price*c.qty : 0); }, 0); }

function renderCart() {
  const el = document.getElementById('cart-content');
  if (!el) return;
  if (cart.length === 0) {
    el.innerHTML = `<div class="cart-empty">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
      <p>Your cart is empty</p>
      <button class="btn-primary" style="max-width:200px;margin:20px auto 0;display:block" onclick="showPage('shop')">Shop Now</button>
    </div>`; return;
  }
  const total = getCartTotal();
  el.innerHTML = `
    <div class="cart-items">
      ${cart.map(c => { const p = PRODUCTS.find(x=>x.id===c.id); if(!p)return ''; return `
        <div class="cart-item">
          <img class="cart-img" src="${p.images[0]}" alt="${p.name}">
          <div class="cart-info">
            <div class="cart-name">${p.name}</div>
            <div class="cart-price">₹${p.price} each</div>
            <div class="cart-qty">
              <button class="qty-btn" onclick="updateQty(${p.id},-1)">−</button>
              <span class="qty-num">${c.qty}</span>
              <button class="qty-btn" onclick="updateQty(${p.id},1)">+</button>
            </div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-weight:700;color:var(--primary);margin-bottom:8px">₹${p.price*c.qty}</div>
            <button class="cart-remove" onclick="removeFromCart(${p.id})" title="Remove">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
            </button>
          </div>
        </div>`; }).join('')}
    </div>
    <div class="cart-summary">
      <div class="cart-row"><span>Subtotal</span><span>₹${total}</span></div>
      <div class="cart-row"><span>Delivery</span><span style="color:var(--accent)">Free</span></div>
      <div class="cart-row total"><span>Total</span><span>₹${total}</span></div>
      <button class="btn-form" onclick="showPage('checkout')">Proceed to Checkout →</button>
    </div>`;
}

/* ── Wishlist ── */
function toggleWish(id, btn) {
  if (wishlist.includes(id)) {
    wishlist = wishlist.filter(x => x !== id);
    if (btn) { btn.classList.remove('active'); btn.querySelector('svg').setAttribute('fill','none'); btn.querySelector('svg').setAttribute('stroke','currentColor'); }
    showToast('Removed from wishlist');
  } else {
    wishlist.push(id);
    if (btn) { btn.classList.add('active'); btn.querySelector('svg').setAttribute('fill','#e05555'); btn.querySelector('svg').setAttribute('stroke','#e05555'); }
    showToast('Added to wishlist!');
  }
  saveWish();
  if (document.getElementById('page-wishlist')?.classList.contains('active')) renderWishlist();
}

function renderWishlist() {
  const g = document.getElementById('wishlist-grid');
  const empty = document.getElementById('wishlist-empty');
  if (!g) return;
  if (wishlist.length === 0) { g.innerHTML=''; empty && (empty.style.display='block'); return; }
  if (empty) empty.style.display = 'none';
  g.innerHTML = wishlist.map(id => PRODUCTS.find(p=>p.id===id)).filter(Boolean).map(p=>productCard(p)).join('');
}

/* ── Search ── */
function handleSearch(val) {
  const res = document.getElementById('search-results');
  if (!res) return;
  if (!val.trim()) { res.classList.remove('show'); return; }
  const matches = PRODUCTS.filter(p => p.name.toLowerCase().includes(val.toLowerCase()) || p.category.toLowerCase().includes(val.toLowerCase()));
  if (matches.length === 0) { res.innerHTML='<div style="padding:14px 20px;font-size:.85rem;color:var(--text-muted)">No products found</div>'; res.classList.add('show'); return; }
  res.innerHTML = matches.map(p => `<div class="search-result-item" onclick="resClick(${p.id})">
    <img src="${p.images[0]}" alt="${p.name}">
    <div><div class="sr-name">${p.name}</div><div class="sr-price">₹${p.price} · ${p.category}</div></div>
  </div>`).join('');
  res.classList.add('show');
}
function resClick(id) {
  document.getElementById('search-results')?.classList.remove('show');
  const si = document.getElementById('search-input');
  if (si) si.value = '';
  showProduct(id);
}
document.addEventListener('click', e => {
  if (!e.target.closest('.search-wrap')) document.getElementById('search-results')?.classList.remove('show');
});

/* ── Checkout ── */
function buyNow(id) { addToCart(id); showPage('checkout'); }

function renderCheckout(step) {
  checkoutStep = step;
  const el = document.getElementById('checkout-content');
  if (!el) return;
  const stepsHTML = `
    <div class="checkout-steps">
      ${['Address','Payment','Review'].map((label,i) => `
        <div class="checkout-step ${step>=i+1?'active':''} ${step>i+1?'done':''}">
          <div class="step-circle">${step>i+1?'✓':i+1}</div>
          <div class="step-label">${label}</div>
        </div>`).join('')}
    </div>`;

  if (step === 1) {
    el.innerHTML = stepsHTML + `
      <div class="checkout-section">
        <h3>Delivery Address</h3>
        <div class="form-group"><label>Full Name</label><input id="co-name" value="${currentUser?.name||''}" placeholder="Your full name"></div>
        <div class="form-row">
          <div class="form-group"><label>Phone</label><input id="co-phone" type="tel" placeholder="+91 XXXXX XXXXX"></div>
          <div class="form-group"><label>Email</label><input id="co-email" type="email" placeholder="email@example.com"></div>
        </div>
        <div class="form-group"><label>Address</label><input id="co-addr" placeholder="House no, street, area"></div>
        <div class="form-row">
          <div class="form-group"><label>City</label><input id="co-city" placeholder="City"></div>
          <div class="form-group"><label>State</label><input id="co-state" placeholder="State"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Pincode</label><input id="co-pin" placeholder="462042"></div>
          <div class="form-group"><label>Landmark (optional)</label><input id="co-land" placeholder="Near…"></div>
        </div>
      </div>
      <button class="btn-form" onclick="coNext1()">Continue to Payment →</button>`;
  } else if (step === 2) {
    el.innerHTML = stepsHTML + `
      <div class="checkout-section">
        <h3>Payment Method</h3>
        ${[['upi','UPI (Google Pay, PhonePe, Paytm)'],['card','Credit / Debit Card'],['nb','Net Banking'],['cod','Cash on Delivery']].map(([id,label]) => `
          <div class="payment-option ${id==='upi'?'selected':''}" id="pm-${id}" onclick="selectPM('${id}')">
            <input type="radio" name="pm" ${id==='upi'?'checked':''}> <span class="payment-label">${label}</span>
          </div>`).join('')}
        <div id="pm-upi-field" style="margin-top:12px">
          <div class="form-group"><label>UPI ID</label><input id="co-upi" placeholder="yourname@upi"></div>
        </div>
      </div>
      <div class="btn-row">
        <button class="btn-back-form" onclick="renderCheckout(1)">← Back</button>
        <button class="btn-form" onclick="coNext2()">Review Order →</button>
      </div>`;
    checkoutPM = 'upi';
  } else if (step === 3) {
    const total = getCartTotal();
    el.innerHTML = stepsHTML + `
      <div class="checkout-section">
        <h3>Order Summary</h3>
        <div class="review-items">
          ${cart.map(c => { const p=PRODUCTS.find(x=>x.id===c.id); return p?`<div class="review-item"><img src="${p.images[0]}" alt="${p.name}"><div><strong>${p.name}</strong><div style="color:var(--text-muted)">Qty: ${c.qty} × ₹${p.price}</div></div><div style="margin-left:auto;font-weight:700">₹${p.price*c.qty}</div></div>`:'';}).join('')}
        </div>
        <div style="border-top:1px solid var(--border);padding-top:12px;margin-top:4px">
          <div style="display:flex;justify-content:space-between;font-size:.88rem;color:var(--text-muted);margin-bottom:6px"><span>Subtotal</span><span>₹${total}</span></div>
          <div style="display:flex;justify-content:space-between;font-size:.88rem;color:var(--text-muted);margin-bottom:6px"><span>Delivery</span><span style="color:var(--accent)">Free</span></div>
          <div style="display:flex;justify-content:space-between;font-weight:700;color:var(--primary);font-size:1.05rem;padding-top:8px;border-top:1px solid var(--border)"><span>Total</span><span>₹${total}</span></div>
        </div>
      </div>
      <div class="checkout-section" style="font-size:.87rem;color:var(--text-muted);line-height:1.75">
        <h3>Delivery to</h3>
        <p>${checkoutData.name||''} · ${checkoutData.phone||''}<br>${checkoutData.addr||''}, ${checkoutData.city||''}, ${checkoutData.state||''} - ${checkoutData.pin||''}</p>
        <p style="margin-top:8px">Payment: ${checkoutPM==='upi'?'UPI':checkoutPM==='card'?'Credit/Debit Card':checkoutPM==='nb'?'Net Banking':'Cash on Delivery'}</p>
      </div>
      <div class="btn-row">
        <button class="btn-back-form" onclick="renderCheckout(2)">← Back</button>
        <button class="btn-form" onclick="placeOrder()">Place Order ✓</button>
      </div>`;
  }
}

function selectPM(pm) {
  ['upi','card','nb','cod'].forEach(id => document.getElementById('pm-'+id)?.classList.remove('selected'));
  document.getElementById('pm-'+pm)?.classList.add('selected');
  checkoutPM = pm;
  const upiField = document.getElementById('pm-upi-field');
  if (upiField) upiField.style.display = pm === 'upi' ? 'block' : 'none';
}

function coNext1() {
  const name=document.getElementById('co-name').value;
  const phone=document.getElementById('co-phone').value;
  const addr=document.getElementById('co-addr').value;
  const city=document.getElementById('co-city').value;
  const state=document.getElementById('co-state').value;
  const pin=document.getElementById('co-pin').value;
  if (!name||!phone||!addr||!city||!state||!pin) { showToast('Please fill all required fields'); return; }
  checkoutData = { name, phone, addr, city, state, pin, email: document.getElementById('co-email').value };
  renderCheckout(2);
}
function coNext2() { renderCheckout(3); }

function placeOrder() {
  const orderId = 'NV' + Date.now().toString().slice(-8);
  document.getElementById('order-id-text').textContent = 'Order ID: ' + orderId;
  openModal('success-modal');
}

/* ── Auth ── */
function openLogin() { openModal('login-modal'); }
function toggleSignup() {
  document.getElementById('login-form-wrap').style.display = document.getElementById('login-form-wrap').style.display==='none'?'block':'none';
  document.getElementById('signup-form-wrap').style.display = document.getElementById('signup-form-wrap').style.display==='none'?'block':'none';
}
function doLogin() {
  const email=document.getElementById('login-email').value;
  const pass=document.getElementById('login-pass').value;
  if (!email||!pass) { showToast('Please enter email and password'); return; }
  currentUser = { email, name: email.split('@')[0] };
  localStorage.setItem('nv_user', JSON.stringify(currentUser));
  closeModal('login-modal'); showToast('Welcome back, '+currentUser.name+'!');
}
function doSignup() {
  const name=document.getElementById('signup-name').value;
  const email=document.getElementById('signup-email').value;
  const pass=document.getElementById('signup-pass').value;
  if (!name||!email||!pass) { showToast('Please fill all fields'); return; }
  currentUser = { name, email };
  localStorage.setItem('nv_user', JSON.stringify(currentUser));
  closeModal('login-modal'); showToast('Welcome, '+name+'!');
}

/* ── Modals ── */
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('open');
});

/* ── Policy Pages ── */
function showPolicyPage(title) {
  const content = POLICIES[title];
  document.getElementById('policy-heading').textContent = title;
  const bc = document.getElementById('policy-breadcrumb');
  if (bc) bc.textContent = title;
  const el = document.getElementById('policy-content');
  if (el) {
    const lines = (content || 'Content coming soon.').split('\n');
    el.innerHTML = lines.map((l, i) => i===0 ? `<h2>${l}</h2>` : l.trim() ? `<p>${l}</p>` : '').join('') +
      `<button class="btn-primary" style="margin-top:30px" onclick="showPage('home')">← Back to Home</button>`;
  }
  showPage('policy');
}

/* ── Mobile Bottom Nav ── */
(function () {
  const tabs = document.querySelectorAll('.bnav-tab');
  tabs.forEach(tab => tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
  }));
  const homeTab = document.querySelector('.bnav-tab[data-tab="home"]');
  if (homeTab) homeTab.classList.add('active');
})();

/* ── Reveal Animations (IntersectionObserver) ── */
let revealObserver;
function initReveal() {
  if (!('IntersectionObserver' in window)) {
    document.querySelectorAll('.rv').forEach(el => el.classList.add('visible')); return;
  }
  if (!revealObserver) {
    revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.add('visible'); revealObserver.unobserve(entry.target); }
      });
    }, { threshold: 0.07, rootMargin: '0px 0px -40px 0px' });
  }
  document.querySelectorAll('.rv:not(.visible)').forEach(el => {
    if (!el.closest('#preloader') && !el.closest('.cat-track') && !el.closest('.test-track')) {
      revealObserver.observe(el);
    }
  });
}

/* ── Preloader ── */
function hidePreloader() {
  const pl = document.getElementById('preloader');
  if (!pl) return;
  pl.classList.add('hidden');
  setTimeout(() => pl?.parentNode?.removeChild(pl), 800);
}

/* ── Init ── */
function init() {
  buildCatCarousel();
  renderHomeProducts();
  buildFAQ();
  buildTestimonials();
  renderShopGrid('all');
  updateCartBadge();

  // Preloader: wait for animations to finish (2×1.1s) and page load
  const startTime = Date.now();
  function tryHide() {
    const elapsed = Date.now() - startTime;
    const delay = Math.max(2400 - elapsed, 0);
    setTimeout(hidePreloader, delay);
  }
  if (document.readyState === 'complete') { tryHide(); }
  else { window.addEventListener('load', tryHide); setTimeout(hidePreloader, 5000); }

  // Reveal animations
  setTimeout(initReveal, 400);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
